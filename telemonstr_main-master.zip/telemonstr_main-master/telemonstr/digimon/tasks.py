from telemonstr.celery import app


@app.task
def update_bc_data_task():
    try:
        from digimon.functions import update_bc_data
        update_bc_data()

    except Exception as e:
        print(e)


