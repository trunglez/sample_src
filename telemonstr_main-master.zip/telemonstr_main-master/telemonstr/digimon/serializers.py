from rest_framework.serializers import ModelSerializer
from digimon.models import *
from rest_framework import serializers


class CurrencyDetailSerializer(ModelSerializer):
    #create custom field
    rate_from_count = serializers.SerializerMethodField('get_rate_from_count')
    rate_to_count = serializers.SerializerMethodField('get_rate_to_count')
    code_name = serializers.SerializerMethodField('get_code_name')

    def get_code_name(self, value):
        return value.code.code

    def get_rate_from_count(self, value):
        return Rate.objects.filter(from_currency=value.pk).count()
    def get_rate_to_count(self, value):
        return Rate.objects.filter(to_currency=value.pk).count()
    class Meta:
        model = Currency
        fields = '__all__'

class RateDetailSerializer(ModelSerializer):
    from_currency_name = serializers.SerializerMethodField('get_from_currency_name')
    to_currency_name = serializers.SerializerMethodField('get_to_currency_name')


    def get_from_currency_name(self, value):
        return value.from_currency.name

    def get_to_currency_name(self, value):
        return value.to_currency.name

    class Meta:
        model = Rate
        fields = '__all__'

class TopExchangeSerializer(ModelSerializer):
    rates = serializers.SerializerMethodField('get_currencies')

    popular_rates = serializers.SerializerMethodField('get_popular_rates')
    def get_currencies(self, value):
        return Rate.objects.filter(exchange=value.pk).count()

    def get_popular_rates(self, value):
        queryset = Rate.objects.filter(exchange=value.pk).filter(from_currency__tags = 2).filter(to_currency__tags = 2)[:10]
        serializer = RateDetailSerializer(queryset, many=True)
        return serializer.data

    class Meta:
        model = Exchange
        fields = '__all__'

class CurrencySerializer(ModelSerializer):
    code_name = serializers.SerializerMethodField('get_code_name')
    active = serializers.SerializerMethodField('get_active')

    def get_active(self, value):
        return True

    def get_code_name(self, value):
        return value.code.code
    class Meta:
        model = Currency
        fields = '__all__'

class ExchangeSerializer(ModelSerializer):
    class Meta:
        model = Exchange
        fields = '__all__'

class RateResultSerializer(ModelSerializer):
    exchange = ExchangeSerializer()
    from_currency = CurrencySerializer()
    to_currency = CurrencySerializer()
    class Meta:
        model = Rate
        fields = '__all__'

class CryptotagSerializer(ModelSerializer):
    tag_currencies = serializers.SerializerMethodField('get_currencies')
    active= serializers.SerializerMethodField('get_active')

    def get_active(self, value):
        return True



    def get_currencies(self, value):
        queryset = Currency.objects.filter(tags=value.pk)
        serializer = CurrencySerializer(queryset, many=True)
        return serializer.data

    class Meta:
        model = Cryptotag
        fields = '__all__'