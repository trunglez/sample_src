from django.contrib import admin
from .models import *
# Register your models here.
class CryptotagAdmin(admin.ModelAdmin):
    list_display = ("pk","name")
    verbose_name_plural = "Cryptotags"

class CurrencyAdmin(admin.ModelAdmin):
    list_display = ("pk","name","code", "get_tags")
    verbose_name_plural = "Currencies"

    def get_tags(self, obj):
        return [tags.name for tags in obj.tags.all()]

class CodeAdmin(admin.ModelAdmin):
    list_display = ("pk","code")
    verbose_name_plural = "Codes"

class ExchangeAdmin(admin.ModelAdmin):
    list_display = ("pk","name","url")
    verbose_name_plural = "Exchanges"

class CityAdmin(admin.ModelAdmin):
    list_display = ("pk","name", "name_en", "country_code")
    verbose_name_plural = "Cities"

class RateAdmin(admin.ModelAdmin):
    list_display = ("pk","from_currency", "to_currency", "exchange", "city")
    verbose_name_plural = "Rates"

admin.site.register(Cryptotag,CryptotagAdmin)
admin.site.register(Currency,CurrencyAdmin)
admin.site.register(Code,CodeAdmin)
admin.site.register(Exchange,ExchangeAdmin)
admin.site.register(City,CityAdmin)
admin.site.register(Rate,RateAdmin)