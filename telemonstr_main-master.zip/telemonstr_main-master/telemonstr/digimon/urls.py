from django.urls import path
from .views import *
from rest_framework.routers import DefaultRouter
router = DefaultRouter()
router.register('currencies', CurrencyViewSet, basename = 'currencies')
router.register('rates', RateViewSet, basename = 'rates')
router.register('cryptotags', CryptotagViewSet, basename = 'cryptotags')
router.register('exchanges', ExchangeViewSet, basename = 'exchanges')

currency_api_list = CurrencyViewSet.as_view({'get': 'list'})
currency_api_detail = CurrencyViewSet.as_view({'get': 'retrieve'})
echanges_api_result_list = RateViewSet.as_view({'get': 'list'})
cryptotags_api_result_list = CryptotagViewSet.as_view({'get': 'list'})
exchanges_api_result_list = ExchangeViewSet.as_view({'get': 'list'})

urlpatterns = []

urlpatterns.append(path('', digimon_main_page))
urlpatterns.append(path('api/currencies/', currency_api_list, name='api-currencies'))
urlpatterns.append(path('api/currency/<int:pk>/', currency_api_detail, name='api-currency-detail'))
urlpatterns.append(path('api/exchanges/<slug:from_code>/<slug:to_code>/', echanges_api_result_list, name='api-exchanges-result'))
urlpatterns.append(path('api/cryptotags/', cryptotags_api_result_list, name='cryptotags-api-result-list'))
urlpatterns.append(path('api/exchanges/', exchanges_api_result_list, name='exchanges-api-result-list'))