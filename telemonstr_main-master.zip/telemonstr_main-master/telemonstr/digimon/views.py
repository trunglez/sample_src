from django.shortcuts import render
from digimon.models import *
from digimon.serializers import *
from rest_framework.viewsets import ModelViewSet
from django.http import HttpResponse
from django.http import JsonResponse
from django.core import serializers
import json
from django.db.models import Min, Max, Prefetch, Count, Sum, F, Q

# Create your views here.
def digimon_main_page(request):
    return render(request, 'digimon_main.html')

class CurrencyViewSet(ModelViewSet):
    #sort by Rate from_currency count
    #prefetch = Prefetch('from_currency', Rate.objects.all())
    #queryset = Currency.objects.all().prefetch_related(prefetch).annotate(rate_from_count=Count('from_currency')).order_by('-rate_from_count')
    queryset = Currency.objects.all()
    serializer_class = CurrencyDetailSerializer
    lookup_field = 'currency_id'
    def get_queryset(self):
        return self.queryset

    def get_object(self):
        currency_id = self.kwargs['pk']
        return self.queryset.get(pk=currency_id)

    def list(self, request):
        currencies = self.queryset
        serializers = self.get_serializer(currencies, many=True)
        return HttpResponse(json.dumps(serializers.data), content_type="application/json")

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializers = self.get_serializer(instance, many=False)
        return HttpResponse(json.dumps(serializers.data), content_type="application/json")


class RateViewSet(ModelViewSet):
    queryset = Rate.objects.all().order_by('-from_rate').order_by('-to_rate')
    serializer_class = RateResultSerializer
    lookup_url_kwarg = ['from_id','to_id']
    lookup_field = ['from_currency','to_currency']

    def get_queryset(self):
        return self.queryset


    def list(self, request, *args, **kwargs):
        from_code = Code.objects.get(code = self.kwargs['from_code'])
        to_code = Code.objects.get(code = self.kwargs['to_code'])
        from_id = Currency.objects.get(code=from_code).pk
        to_id = Currency.objects.get(code=to_code).pk
        if self.queryset.filter(from_currency=from_id).filter(to_currency=to_id).first().to_rate == 1:
            exchanges = self.queryset.filter(from_currency=from_id).filter(to_currency=to_id).all().order_by('from_rate')
        else:
            exchanges = self.queryset.filter(from_currency=from_id).filter(to_currency=to_id).all().order_by('-to_rate')

        serializers = self.get_serializer(exchanges, many=True)
        return HttpResponse(json.dumps(serializers.data), content_type="application/json")

class CryptotagViewSet(ModelViewSet):
    queryset = Cryptotag.objects.all()
    serializer_class = CryptotagSerializer

class ExchangeViewSet(ModelViewSet):
    # queryset limit 5
    queryset = Exchange.objects.all().annotate(rate_count=Count('rate')).order_by('-rate_count')[:10]
    serializer_class = TopExchangeSerializer


