from django.db import models

class Code(models.Model):
    code = models.CharField(null = False, max_length=20, unique=True)
    bc_id = models.IntegerField(default=0, null=False, blank=False)
    def __str__(self):
        return f"{self.code}:{self.bc_id}"

class Cryptotag(models.Model):
    name = models.CharField(max_length=200)
    def __str__(self):
        return f"{self.name}"

class Currency(models.Model):
    name = models.CharField(max_length=200, unique=True)
    bc_id = models.IntegerField(default=0, null=False, blank=False)
    bc_position = models.IntegerField(default=0, null=False, blank=False)
    code = models.ForeignKey(Code, on_delete=models.CASCADE)
    tags = models.ManyToManyField(Cryptotag, blank=True)
    def __str__(self):
        return f"{self.name}"

class Exchange(models.Model):
    name = models.CharField(max_length=200, unique=True)
    bc_id = models.IntegerField(default=0, null=False, blank=False)
    url = models.CharField(max_length=200, unique=True, null=True, blank=True)
    def __str__(self):
        return f"{self.name}"

class City(models.Model):
    name = models.CharField(max_length=200)
    bc_id = models.IntegerField(default=0, null=False, blank=False)
    name_en = models.CharField(max_length=200, null=True, blank=True)
    country_code = models.CharField(max_length=5, null=True, blank=True)
    def __str__(self):
        return f"{self.name}"

class Rate(models.Model):
    from_currency = models.ForeignKey(Currency, on_delete=models.CASCADE, related_name='from_currency')
    to_currency = models.ForeignKey(Currency, on_delete=models.CASCADE, related_name='to_currency')
    exchange = models.ForeignKey(Exchange, on_delete=models.CASCADE, null=True, blank=True)
    from_rate = models.FloatField(default=0.0, null=False, blank=False)
    to_rate = models.FloatField(default=0.0, null=False, blank=False)
    reserve = models.FloatField(default=0.0, null=False, blank=False)
    min = models.FloatField(default=0.0, null=False, blank=False)
    max = models.FloatField(default=0.0, null=False, blank=False)

    city = models.ForeignKey(City, on_delete=models.CASCADE,null=True, blank=True)
    updated = models.DateTimeField(auto_now=True, auto_now_add=False, null=True, blank=True)


    def __str__(self):
        return f"{self.from_currency.code.code}:{self.to_currency.code.code} {self.exchange.name} -> {self.from_rate} {self.to_rate}"

