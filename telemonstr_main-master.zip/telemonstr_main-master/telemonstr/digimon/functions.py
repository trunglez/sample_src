from digimon.models import City, Exchange, Currency, Rate, Code, Cryptotag
import requests
import lxml
from bs4 import BeautifulSoup
import json
import time
from urllib.parse import urlparse




def update_cities():
    with open('p2p/static/bestchange/bm_cities.dat', 'r', encoding='windows-1251') as f:
        file_data = f.readlines()
        count_saved = 0
        count_updated = 0
    for line in file_data:
            city = line.split(';')[1]
            city_id = line.split(';')[0]
            if City.objects.filter(name=city).count()==0:
                c = City(
                    name = city,
                    bc_id = city_id
                )
                c.save()
                count_saved +=1
            else:
                count_updated +=1

    print(f"{count_saved} cities saved, {count_updated} cities updated")


def update_exchange():
    with open('p2p/static/bestchange/bm_exch.dat', 'r', encoding='windows-1251') as f:
        file_data = f.readlines()
        count_saved = 0
        count_updated = 0
    for line in file_data:
            exchange = line.split(';')[1]
            exchange_id = line.split(';')[0]
            if Exchange.objects.filter(name=exchange).count()==0:
                c = Exchange(
                    name = exchange,
                    bc_id = exchange_id
                )
                c.save()
                count_saved +=1
            else:
                count_updated +=1

    print(f"{count_saved} exchanges saved, {count_updated} exchanges updated")

def load_codes():
    with open('p2p/static/bestchange/bm_cycodes.dat', 'r', encoding='windows-1251') as f:
        file_data = f.readlines()
        count_saved = 0
        count_updated = 0
        for line in file_data:

            code = line.split(';')[1].strip()
            bc_id = line.split(';')[0]

            if Code.objects.filter(code=code).count()==0:
                c = Code(
                    code = code.strip(),
                    bc_id = bc_id,
                )
                c.save()
                count_saved +=1
            else:
                count_updated +=1

    print(f"{count_saved} codes saved, {count_updated} codes updated")

def load_currencies():
    with open('p2p/static/bestchange/bm_cy.dat', 'r', encoding='windows-1251') as f:
        file_data = f.readlines()
        count_saved = 0
        count_updated = 0
        for line in file_data:
            bc_position = line.split(';')[1]
            bc_id = int(line.split(';')[0])
            name = line.split(';')[2].strip()
            code = Code.objects.filter(bc_id=int(line.split(';')[0])).first()

            if Currency.objects.filter(bc_id=bc_id).count()==0:
                c = Currency(
                    bc_position = bc_position,
                    bc_id = bc_id,
                    name = name,
                    code = code
                )
                c.save()
                count_saved +=1
            else:
                count_updated +=1

    print(f"{count_saved} currencies saved, {count_updated} currencies updated")

def load_rates():
    with open('p2p/static/bestchange/bm_rates.dat', 'r', encoding='windows-1251') as f:
        file_data = f.readlines()
        create_rates = []
        update_rates = []

        currencies = Currency.objects.all()
        exchanges = Exchange.objects.all()
        cities = City.objects.all()

        from_currency = None
        to_currency = None
        city = None
        exchange = None
        save_iter = 0
        update_iter = 0

        count_saved = 0
        count_updated = 0

        for line in file_data:
            for curr in currencies:
                if curr.bc_id == int(line.split(';')[0]):
                    from_currency = curr
                if curr.bc_id == int(line.split(';')[1]):
                    to_currency = curr
            for exch in exchanges:
                if exch.bc_id == int(line.split(';')[2]):
                    exchange = exch

            if line.split(';')[10]==0:
                city = None
            else:
                for c in cities:
                    if c.bc_id == int(line.split(';')[10]):
                        city = c

            from_rate = line.split(';')[3]
            to_rate = line.split(';')[4]
            reserve = line.split(';')[5]
            min = line.split(';')[8]
            max = line.split(';')[9]

            if Rate.objects.filter(
                    from_currency=from_currency,
                    to_currency=to_currency,
                    exchange=exchange,
                    city=city).count()==0:
                r = Rate(
                    from_currency = from_currency,
                    to_currency = to_currency,
                    exchange = exchange,
                    city = city,
                    from_rate = from_rate,
                    to_rate = to_rate,
                    reserve = reserve,
                    min = min,
                    max = max
                )
                save_iter += 1
                create_rates.append(r)
                #print(f"Rate {from_currency} -> {to_currency} added")
            else:
                #update
                r = Rate.objects.get(
                    from_currency=from_currency,
                    to_currency=to_currency,
                    exchange=exchange,
                    city=city)
                r.from_rate = from_rate
                r.to_rate = to_rate
                r.reserve = reserve
                r.min = min
                r.max = max
                update_rates.append(r)
                update_iter += 1
                #print(f"Rate {from_currency} -> {to_currency} updated")
            if save_iter>1000:
                Rate.objects.bulk_create(create_rates)
                create_rates = []
                count_saved += save_iter
                save_iter = 0


            if update_iter>1000:
                Rate.objects.bulk_update(update_rates, ['from_rate', 'to_rate', 'reserve', 'min', 'max'])
                update_rates = []
                count_updated += update_iter
                update_iter = 0

        Rate.objects.bulk_create(create_rates)
        Rate.objects.bulk_update(update_rates, ['from_rate', 'to_rate', 'reserve', 'min', 'max'])
        count_saved += len(create_rates)
        count_updated += len(update_rates)

def update_bc_data():
    try:
        update_cities()
        update_exchange()
        load_codes()
        load_currencies()
        load_rates()
        return True
    except Exception as e:
        print(e)
        return False

def clear_bc_data():
    Currency.objects.all().delete()
    Exchange.objects.all().delete()
    Code.objects.all().delete()
    Rate.objects.all().delete()
    City.objects.all().delete()


def import_tags():
    url = "https://img.exchangesumo.com/wp-content/cache/autoptimize/js/autoptimize_single_6a243afe7fe1f1dadb968c2df4f5e047.js?v=1668168"
    response = requests.get(url)
    data = response.text.replace('var vlt_list=','')
    data = data[:-1]

    data = json.loads(data)

    crypto_curr_teg = Cryptotag.objects.get(pk=1)
    payment_system_tag = Cryptotag.objects.get(pk=3)
    cash_tag = Cryptotag.objects.get(pk=7)
    money_transfers_tag = Cryptotag.objects.get(pk=6)
    internet_banking_tag = Cryptotag.objects.get(pk=5)
    exchange_code_tag = Cryptotag.objects.get(pk=4)

    for item in data['1']['items']:
        code = item['slug'].strip()

        code_obj = Code.objects.filter(code=code).first()
        if code_obj:
            curr = Currency.objects.get(code=code_obj)
            curr.tags.add(payment_system_tag)
            curr.save()

    for item in data['2']['items']:
        code = item['slug'].strip()

        code_obj = Code.objects.filter(code=code).first()
        if code_obj:
            curr = Currency.objects.get(code=code_obj)
            curr.tags.add(cash_tag)
            curr.save()

    for item in data['3']['items']:
        code = item['slug'].strip()

        code_obj = Code.objects.filter(code=code).first()
        if code_obj:
            curr = Currency.objects.get(code=code_obj)
            curr.tags.add(internet_banking_tag)
            curr.save()

    for item in data['4']['items']:
        code = item['slug'].strip()

        code_obj = Code.objects.filter(code=code).first()
        if code_obj:
            curr = Currency.objects.get(code=code_obj)
            curr.tags.add(money_transfers_tag)
            curr.save()


    for item in data['5']['items']:
        code = item['slug'].strip()

        code_obj = Code.objects.filter(code=code).first()
        if code_obj:
            curr = Currency.objects.get(code=code_obj)
            curr.tags.add(crypto_curr_teg)
            curr.save()

    for item in data['6']['items']:
        code = item['slug'].strip()

        code_obj = Code.objects.filter(code=code).first()
        if code_obj:
            curr = Currency.objects.get(code=code_obj)
            curr.tags.add(exchange_code_tag)
            curr.save()

    curr = Currency.objects.filter(tags__in=[crypto_curr_teg]).all()

def translate_cities():
    from translate import Translator
    translator = Translator(from_lang="russian", to_lang="english")
    cities = City.objects.filter(name_en=None).all()
    for city in cities:
        print(city.name)
        try:
            city.name_en = translator.translate(city.name)
            print(city.name_en)
            city.save()
        except Exception as e:
            print(e)

        time.sleep(1)

def get_country_from_city(city_name):
    #get country name from city name
    url = f"https://nominatim.openstreetmap.org/search?q={city_name}&format=json&addressdetails=1&limit=1"
    response = requests.get(url)
    data = response.json()
    if data:
        country = data[0]['address']['country_code']
        return country
    else:
        return None

def update_cities():
    #update cities with country
    cities = City.objects.filter(country_code=None).all()
    for city in cities:
        try:
            country_code = get_country_from_city(city.name_en)
            if country_code:
                city.country_code = country_code
                city.save()
                print(f"{city.name_en} updated with country {country_code}")

        except Exception as e:
            print(e)

        time.sleep(1)

def get_echangers_urls():

    url ='https://www.bestchange.com/list.html'
    response = requests.get(url)
    data = response.text
    soup = BeautifulSoup(data, 'html.parser')
    links = soup.select("#content_table > tbody > tr > td:nth-child(2) > div > a")
    exchanges = soup.select("#content_table > tbody > tr > td:nth-child(2) > div > div > div")

    redirect_licks = []
    i=0
    for link in links:
        redirect_licks.append(
            {
                'url': link.get('href'),
                'name': exchanges[i].text.strip()

            }
        )
        i+=1


    for link in redirect_licks:

        try:
            response = requests.get(link['url'], timeout=10)
            exchange = Exchange.objects.filter(name=link['name']).filter(url = None).first()
            if exchange:
                ex_url = urlparse(response.url)
                exchange.url = ex_url.netloc
                exchange.save()
                print(f"{exchange.name} updated with url {exchange.url}")
        except Exception as e:
            print(e)

        time.sleep(10)

    return redirect_licks
