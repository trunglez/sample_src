const app = new Vue({
    el: '#sender_app',
    data:{
        sender_data: [],
    },
    created: function(){
        console.log('work')
        vm = this
        url = new URL(window.location.href)
        var pk = url.pathname.split('/')[4]
        console.log(pk)
        axios.get('/p2p/api/sender/'+pk).then(function(response){
            vm.sender_data = response.data
        })

    },

})
