function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
axios.defaults.xsrfCookieName = 'csrftoken';
axios.defaults.xsrfHeaderName = 'X-CSRFToken';

const app = new Vue({
    el: '#senders_app',
    data:{
        senders_data: [],
        csrftoken: getCookie('csrftoken'),
    },
    created: function(){

        vm = this
        axios.get('/p2p/senders/?format=json').then(function(response){
            vm.senders_data = response.data
        })

    },

    methods: {
        unlock_card(pk){
            var data = {'pk':pk}
            var headers = {
                    'X-CSRFToken': getCookie('csrftoken'),
                    'csrfmiddlewaretoken': getCookie('csrftoken')
                }

            axios.post('/p2p/unlockcard/', data, headers).then(response=>{
                console.log(response)
                //axios.get('/p2p/senders/?format=json').then(function(response){
                //    vm.senders_data = response.data
                //})
                for (const [sender_key, sender] of Object.entries(app.senders_data))
                    for (const [drop_key, drop] of Object.entries(sender.drops))
                        for (const [card_key, card] of Object.entries(drop.cards))
                            if(parseInt(card.id) === parseInt(response.data.pk)){
                                this.senders_data[sender_key].drops[drop_key].cards[card_key].blocked = false
                            }

            }).catch(err=>{
                console.log(err)
            })
        },


        block_card(pk){
        // axios send post request
            var data = {'pk':pk}
            var headers = {
                    'X-CSRFToken': getCookie('csrftoken'),
                    'csrfmiddlewaretoken': getCookie('csrftoken')
                }

            axios.post('/p2p/blockcard/', data, headers).then(response=>{
                console.log(response.data.pk)
                 //axios.get('/p2p/senders/?format=json').then(function(response){
                 //   vm.senders_data = response.data
                 //})
                 // rerender card element by key parameter
                 //parseint
                    this.blocked = true
                 for (const [sender_key, sender] of Object.entries(app.senders_data))
                    for (const [drop_key, drop] of Object.entries(sender.drops))
                        for (const [card_key, card] of Object.entries(drop.cards))
                            if(parseInt(card.id) === parseInt(response.data.pk)){
                                this.senders_data[sender_key].drops[drop_key].cards[card_key].blocked = true
                            }





            }).catch(err=>{
                console.log(err)
            })

        }



    },

})
