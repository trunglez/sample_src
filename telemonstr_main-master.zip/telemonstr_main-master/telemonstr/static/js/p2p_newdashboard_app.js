const app = new Vue({
    el: '#dashboard_app',
    data:{
        curr_data: [],
        chain_data:[],
        fiat: '-',
        crypto: '-',
        bank:'-',
        scrf_tocken:'',

    },
    created: function(){
        const vm = this;

        url_data = window.location.pathname.split('/')
        vm.fiat = url_data[3]
        vm.crypto = url_data[4]
        vm.bank = url_data[5]
        axios.get('/p2p/newdashboard/api/'+url_data[3]+'/'+url_data[4]+'/'+url_data[5]).then(function(response){
            vm.curr_data = response.data
        })
        axios.get('/p2p/api/chains/').then(function(response){
            vm.chain_data = response.data
            // sort vm.chain_data by spread
            vm.chain_data.sort(function(a, b) {
                return b.spread - a.spread;
            })
        })

    },
    watch: {

    }
})



