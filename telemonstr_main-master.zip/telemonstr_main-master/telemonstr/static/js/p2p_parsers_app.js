
const app = new Vue({
    el: '#parsers_app',
    data:{
        parsers_data: [],
    },
    created: function(){
        vm = this
        axios.get('/p2p/api/parsers/').then(function(response){
            vm.parsers_data = response.data
        })

    },
    methods: {
        check: function(e) {
          console.log(e.target.checked)
          console.log(e.target.name)
          if(e.target.checked == true)
            axios.get('/p2p/parsers/swithon/'+e.target.name).then(function(response){
                console.log(response.data)
            })
         if(e.target.checked == false)
            axios.get('/p2p/parsers/swithoff/'+e.target.name).then(function(response){
                console.log(response.data)
            })
        }


     }
})

