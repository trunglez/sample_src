const app = new Vue({
    el: '#ballances_app',
    data:{
        ballances_data: [],
    },
    created: function(){

        vm = this

        axios.get('/p2p/ballances/?format=json').then(function(response){
            vm.ballances_data = response.data
        })

    },

})
