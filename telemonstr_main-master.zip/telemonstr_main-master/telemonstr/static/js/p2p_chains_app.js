const app = new Vue({
    el: '#chains_app',
    data:{
        parsers_data: [],
    },
    created: function(){
        vm = this
        axios.get('/p2p/newdashboard/api/'+url_data[3]+'/'+url_data[4]+'/'+url_data[5]).then(function(response){
            vm.curr_data = response.data
        })

    }
})



