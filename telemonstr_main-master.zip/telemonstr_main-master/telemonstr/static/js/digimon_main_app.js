
const app = new Vue({
    el: '#digimon_main_app',
    data:{
        currencies_from_data: [],
        currencies_to_data : [],
        active_from_id: 0,
        active_to_id:0,
        rates_result: [],
        request_sent:0

    },
    created: function(){
        vm = this
        axios.get('/digimon/api/currencies/').then(function(response){
            vm.currencies_from_data = response.data
            vm.currencies_to_data = Object.assign([], response.data);

            vm.currencies_from_data.sort(function(a, b){
                return parseInt(b.rate_from_count) - parseInt(a.rate_from_count)
            })
            //sort vm.currencies_to_data by rate_to_count
            vm.currencies_to_data.sort(function(a, b){
                return parseInt(b.rate_to_count) - parseInt(a.rate_to_count)
            })

        })

    },
    methods: {
        select_currency_from: function(id){
            console.log(id)
            vm = this
            vm.active_from_id = id
            for (var i = 0; i < vm.currencies_from_data.length; i++) {
                if (vm.currencies_from_data[i].id == id){
                    vm.currencies_from_data[i].selected_from = true
                }
                else{
                    vm.currencies_from_data[i].selected_from = false
                }
            }

            if(vm.active_from_id!= 0 && vm.active_to_id != 0){
                if(vm.request_sent == 0){
                    vm.get_rates_result()
                }
                else{
                    console.log('request already sent')
                }
            }
        },

        select_currency_to: function(id){
            console.log(id)
            vm = this
            vm.active_to_id = id
            for (var i = 0; i < vm.currencies_to_data.length; i++) {
                if (vm.currencies_to_data[i].id == id){
                    vm.currencies_to_data[i].selected_to = true
                }
                else{
                    vm.currencies_to_data[i].selected_to = false
                }
            }
            if(vm.active_from_id!= 0 && vm.active_to_id != 0){
                if(vm.request_sent == 0){
                    vm.get_rates_result()
                }
                else{
                    console.log('request already sent')
                }
            }
        },


        get_rates_result: function(){
            vm = this
            vm.request_sent = 1
            axios.get('/digimon/api/exchanges/' + vm.active_from_id + '/'+vm.active_to_id+'/').then(function(response){
                vm.rates_result = response.data
                vm.request_sent = 0
            })
        },
    }
})

