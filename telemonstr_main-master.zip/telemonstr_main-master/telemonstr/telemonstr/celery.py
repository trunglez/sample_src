from celery.schedules import crontab
from celery import Celery
import json
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'telemonstr.settings')

app = Celery('telemonstr')
app.config_from_object('django.conf:settings', namespace='CELERY')
print(app)

#app.conf.beat_schedule = get_celery_beat_parsers_object()

#load from json file
app.conf.beat_schedule = json.loads(open('celery_beat_parsers.json', 'r').read())


app.conf.beat_schedule['load_progons'] = {
        'task': 'p2p.tasks.loag_progons',
        'schedule': crontab(hour=23,minute=40),
    }
app.conf.beat_schedule['check_bestchange_cash_comition'] = {
        'task': 'p2p.tasks.check_bestchange_cash_comition',
        'schedule': 60.0,
    }
app.conf.beat_schedule['reload_bestchange_file'] = {
        'task': 'p2p.tasks.reload_bestchange_file',
        'schedule': 60.0,
    }

app.conf.beat_schedule['reload_bc_data'] = {
        'task': 'digimon.tasks.update_bc_data_task',
        'schedule': crontab(hour='*/1',minute=10),
    }

app.conf.beat_schedule['count_sender_ballance'] = {
        'task': 'p2p.tasks.count_balance_task',
        'schedule': crontab(hour=23,minute=50),
    }

app.conf.beat_schedule['rewrite_parser_json_file'] = {
        'task': 'p2p.tasks.update_parsers_data',
        'schedule': crontab(hour=23,minute=50),
    }




app.conf.timezone = 'UTC'


app.autodiscover_tasks()