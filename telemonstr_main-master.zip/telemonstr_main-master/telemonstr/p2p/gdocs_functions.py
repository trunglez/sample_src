import gspread
import re
import time

gc = gspread.service_account(filename='p2p/gsconfig/telemonstr-305101ea7930.json')
#get all sheets
#get google spreadsheet list

def get_google_spreadsheet_list():
    try:
        sh = gc.open_by_key('1oT8O2I49Tbhs3GWF7RRgDsOlDvAmn4hfqdvm4dmSMO8')
        sheets = sh.worksheets()
        print(sheets)
        result = []
        for sheet in sheets:
            cards = sheet.col_values(2)
            totals = sheet.col_values(6)

            for row in cards:
                #check type int
                val = row
                row = row.replace(' ','')
                if row.isdigit():
                    row = int(row)
                    idxs = [i for i, v in enumerate(cards) if v == val]
                    for idx in idxs:
                        try:
                            total = re.sub(r"[^0-9.,]+", r"", totals[idx])
                            summ = int(float(total.replace(",", ".")))
                        except:
                            summ = 0

                        #delete list element by index

                        if row !='' and summ>0:
                            result.append({'card': row, 'summ': int(summ), 'date': sheet.title})
            time.sleep(5)


        return result
    except Exception as ex:
        print(ex)
        return False












