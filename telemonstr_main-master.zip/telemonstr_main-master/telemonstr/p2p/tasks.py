from telemonstr.celery import app
from .models import Qurrency
from .functions import exchange_get_dashboard_data
from p2p.functions import save_celery_beat_parsers_config_to_json
import time
from django.db import close_old_connections, connection
from django.db.models import Q
from celery.schedules import crontab


#check_and_retry_django_db_connection
def check_and_retry_django_db_connection():
    try:
        close_old_connections()
    except:
        time.sleep(1)
        close_old_connections()

    db_conn = False
    while not db_conn:
        try:
            connection.ensure_connection()
            db_conn = True

        except Exception as ex:
            print(ex)
            time.sleep(1)

@app.task
def get_currency_data_controller(fiat, crypto, bank, stock, delay):
    bundle_text = f"{fiat}->{crypto} {stock} [{delay}]"
    while True:
        try:
            start_time = time.time()
            data = exchange_get_dashboard_data(fiat, crypto, bank, stock)
            if data:
                q_buy = Qurrency(
                    stock=stock,
                    crypto=crypto,
                    fiat=fiat,
                    type='b',
                    bank=bank,
                    avg=data[0]['avg']['avg_price'],
                    optimal=data[0]['optimal']['avg_price'],
                    top5=data[0]['top5']['avg_price'],
                )

                q_sell = Qurrency(
                    stock=stock,
                    crypto=crypto,
                    fiat=fiat,
                    type='s',
                    bank=bank,
                    avg=data[1]['avg']['avg_price'],
                    optimal=data[1]['optimal']['avg_price'],
                    top5=data[1]['top5']['avg_price'],
                )
                check_and_retry_django_db_connection()
                q_buy.save()
                q_sell.save()
                iter_time = round(float(time.time() - start_time),2)
                result_digits = f"{data[0]['avg']['avg_price']} - {data[1]['avg']['avg_price']}"
                print(f"parser iteration for {bundle_text} ({result_digits}) finished succesfull after {iter_time} seconds")
            else:
                print("data loading error")

        except Exception as ex:
            print(ex)

        time.sleep(delay)

@app.task
def get_currency_data_controller_beat(fiat, crypto, bank, stock):

    try:
        bundle_text = f"{fiat}->{crypto} {stock}"
        start_time = time.time()
        data = exchange_get_dashboard_data(fiat, crypto, bank, stock)
        if data:
            q_buy = Qurrency(
                stock=stock,
                crypto=crypto,
                fiat=fiat,
                type='b',
                bank=bank,
                avg=data[0]['avg']['avg_price'],
                optimal=data[0]['optimal']['avg_price'],
                top5=data[0]['top5']['avg_price'],
            )

            q_sell = Qurrency(
                stock=stock,
                crypto=crypto,
                fiat=fiat,
                type='s',
                bank=bank,
                avg=data[1]['avg']['avg_price'],
                optimal=data[1]['optimal']['avg_price'],
                top5=data[1]['top5']['avg_price'],
            )
            check_and_retry_django_db_connection()
            q_buy.save()
            q_sell.save()

            iter_time = round(float(time.time() - start_time), 2)
            result_digits = f"{data[0]['avg']['avg_price']} - {data[1]['avg']['avg_price']}"
            print(f"parser iteration for {bundle_text} ({result_digits}) finished succesfull after {iter_time} seconds")
        else:
            print("data loading error")
    except Exception as ex:
        print(ex)




@app.task(time_limit=60)
def check_bestchange_cash_comition():
    from .bestchange_functions import get_bestchange_data_from_zip
    from .models import MoneyChain

    try:
        cash_usdt = round((get_bestchange_data_from_zip("usdt", "usd", "sell", 3, 1)['optimal']['avg_price'] - 1)*-100,2)
        usdt_chash = round((get_bestchange_data_from_zip("usdt", "usd", "buy", 3, 1)['optimal']['avg_price'] - 1)*100,2)

        MoneyChain.objects.filter(Q(pk=5) | Q(pk=4) | Q(pk=3) | Q(pk=13)).update(comittion=usdt_chash)
        MoneyChain.objects.filter(Q(pk=9) | Q(pk=15) | Q(pk=16)).update(comittion=cash_usdt)
        MoneyChain.objects.filter(pk=6).update(comittion=usdt_chash+1.2)
        print(f"cash_usdt: {cash_usdt}, usdt_chash: {usdt_chash}")
    except Exception as ex:
        print(ex)

@app.task(time_limit=300)
def loag_progons():
    from p2p.functions import get_progons
    try:
        result = get_progons()
        print(f'Successfully loaded {result["count"]} Progons')
        if len(result['error_list']) > 0:
            for row in result['error_list']:
                print(f'Error: {row}')

        if len(result['success_list']) > 0:
            for row in result['success_list']:
                print(f'Successfully loaded Progon {row["summ"]} for card {row["card"]} on {row["date"]}')

    except Exception as ex:
        print(ex)

@app.task(time_limit=60)
def reload_bestchange_file():
    from p2p.bestchange_functions import get_bestchange_zip, unzip_file
    status_code = get_bestchange_zip()
    if status_code == 200:
        unzip_file()
    else:
        print(f"Error: bestchange zip file download status code: {status_code}")

@app.task(time_limit=60)
def count_balance_task():
    try:
        from .functions import count_balance
        count_balance()
    except Exception as ex:
        print(ex)

@app.task(time_limit=60)
def update_parsers_data():
    try:
        save_celery_beat_parsers_config_to_json()
    except Exception as ex:
        print(ex)

