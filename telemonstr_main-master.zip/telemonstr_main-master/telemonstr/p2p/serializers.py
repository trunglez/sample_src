from rest_framework.serializers import ModelSerializer
from p2p.models import Sender, Drop, Card, Bank, P2p_transaction, Progon
from rest_framework import serializers
import datetime
from django.db.models import Sum




class BankSerializer(ModelSerializer):
    class Meta:
        model = Bank
        fields = '__all__'

class CardSerializer(ModelSerializer):
    bank = BankSerializer(read_only=True, many=False)

    current_month_total = serializers.SerializerMethodField('get_current_month_total')




    def get_current_month_total(self, value):
        month = datetime.datetime.now().month
        card = Card.objects.get(pk=value.pk)
        current_month_total = 0
        try:
            agregation = card.progon_set.filter(date__month=month).aggregate(Sum('summ'))['summ__sum']
            if agregation:
                current_month_total += float(agregation)
        except Exception as e:
            print(card.progon_set.filter(date__month=month).aggregate(Sum('summ'))['summ__sum'])
            print(e)
        return current_month_total

    class Meta:
        model = Card
        fields = '__all__'

class DropSerializer(ModelSerializer):
    cards = serializers.SerializerMethodField('get_cards')
    banks = serializers.SerializerMethodField('get_banks')

    def get_cards(self, value):
        cards = Card.objects.filter(drop=value.pk)
        return CardSerializer(cards, many=True).data

    def get_banks(self, value):
        banks = Bank.objects.order_by().distinct()
        cards = Card.objects.filter(drop=value.pk)
        month = datetime.datetime.now().month
        result = []
        for bank in banks:
            result.append({'id':bank.pk,'name':bank.name, 'count':0,'month_total':0, 'total':0, 'month_max':bank.month_max, 'status_bar_value':''})

        for i in range(len(result)):
            bank = result[i]
            for card in cards:
                if card.bank.pk == bank['id']:
                    result[i]['count'] += 1
                    month_total = card.progon_set.filter(date__month=month).aggregate(Sum('summ'))['summ__sum']
                    if month_total:
                        result[i]['month_total'] += int(month_total)
                        result[i]['total'] = int(card.progon_set.aggregate(Sum('summ'))['summ__sum'])
                        result[i]['status_bar'] = f"{(result[i]['month_total']/ result[i]['month_max']) * 100}%"

                    total = card.progon_set.aggregate(Sum('summ'))['summ__sum']
                    if total:
                        result[i]['total'] += int(total)

        return result

    class Meta:
        model = Drop
        fields = '__all__'


class SenderSerializer(ModelSerializer):
    drops = serializers.SerializerMethodField('get_drops')

    def get_drops(self, value):
        drops = Drop.objects.filter(sender=value.pk)
        return DropSerializer(drops, many=True).data


    class Meta:
        model = Sender
        fields = ['fio', 'phone', 'telegram', 'comition', 'drops']



class SenderBallanceSerializer(ModelSerializer):
    class Meta:
        model = Sender
        fields = ['pk','fio', 'ballance']


class P2p_transactionSerializer(ModelSerializer):
    progon_date = serializers.SerializerMethodField('get_progon_date')
    progon_summ = serializers.SerializerMethodField('get_summ')
    progon_card = serializers.SerializerMethodField('get_progon_card')
    progon_bank = serializers.SerializerMethodField('get_progon_bank')
    progon_drop = serializers.SerializerMethodField('get_progon_drop')

    def get_progon_drop(self, value):
        return value.progon.card.drop.name

    def get_progon_bank(self, value):
        return value.progon.card.bank.name

    def get_progon_card(self, value):
        return value.progon.card.number

    def get_progon_date(self, value):
        return str(value.progon.date).split(' ')[0]

    def get_summ(self, value):
        return value.progon.summ


    class Meta:
        model = P2p_transaction
        fields = '__all__'


class SenderDetailSerializer(ModelSerializer):
    transactions = serializers.SerializerMethodField('get_transactions')


    def get_transactions(self, value):
        transactions = P2p_transaction.objects.filter(sender=value.pk).order_by('-progon__date')
        return P2p_transactionSerializer(transactions, many=True).data

    class Meta:
        model = Sender
        fields = '__all__'