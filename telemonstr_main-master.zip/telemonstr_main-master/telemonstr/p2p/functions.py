from p2p.huobi_functions import *
from p2p.bestchange_functions import *
from p2p.minfin_functions import *
from p2p.exmo_functions import *
from p2p.whitebit_functions import *
from p2p.models import *
from p2p.binance_stock_functions import *
import json


def count_stock_glas(data):
    total_crypto = 0
    total_fiat = 0
    for item in data:
        total_crypto = total_crypto + float(item['adv']['tradableQuantity'])
        total_fiat = total_fiat + float(item['adv']['price']) * float(item['adv']['tradableQuantity'])
    if total_fiat!= 0 and total_crypto!=0:
        avg_price = total_fiat / total_crypto
    else:
        avg_price = 0
    result = {
        'total_crypto': round(total_crypto,2),
        'total_fiat': round(total_fiat,2),
        'avg_price': round(avg_price,2),
    }
    return result

def get_buy_area(fiat):
    url = "https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/portal/config"
    headers = {
        "Host": "p2p.binance.com",
        "Content-Type": "application/json",
        "Bnc-Uuid": "2499f661-d090-4120-913f-b2437ec0b789",
    }
    payload = {
        "fiat": fiat,
    }
    binance_answer = requests.post(url, data=json.dumps(payload), headers=headers).json()
    buy_assets = binance_answer['data']['areas'][0]['tradeSides'][0]['assets']
    sell_assets = binance_answer['data']['areas'][0]['tradeSides'][1]['assets']
    result = {
        'buy': buy_assets,
        'sell': sell_assets,
    }
    return result

def count_fiat(crypto_label,fiat_label,type,payment_method):
    url = 'https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search'
    headers = {
        "Host": "p2p.binance.com",
        "Content-Type": "application/json",
        "Bnc-Uuid": "2499f661-d090-4120-913f-b2437ec0b789",
    }
    payload = {
        "page": 1,
        "rows": 10,
        "payTypes": [payment_method],
        "asset": crypto_label,
        "tradeType": type,
        "fiat": fiat_label
    }
    # Adding empty header as parameters are being sent in payload
    binance_answer = requests.post(url, data=json.dumps(payload), headers=headers).json()

    result = {
        'stock': 'binance',
        'crypto':crypto_label,
        'fiat':fiat_label,
        'type':type,
        'bank':payment_method,
        'avg': count_stock_glas(binance_answer['data']),
        'optimal': count_stock_glas(binance_answer['data'][6:]),
        'top5': count_stock_glas(binance_answer['data'][:5])
    }

    return result

def get_bank_list(fiat):
    url = "https://p2p.binance.com/bapi/c2c/v2/public/c2c/adv/filter-conditions"
    headers = {
        "Host": "p2p.binance.com",
        "Content-Type": "application/json",
        "Bnc-Uuid": "2499f661-d090-4120-913f-b2437ec0b789",
    }

    payload = {
        "fiat": fiat
    }
    binance_answer = requests.post(url, data=json.dumps(payload), headers=headers).json()
    result = []
    for item in binance_answer['data']['tradeMethods']:
        result.append(item['identifier'])
    return result




def exchange_get_dashboard_data(fiat, crypto, bank, stock):

    result = []
    buy_data = {}
    sell_data = {}

    if stock == "binance":
        buy_data = count_fiat(crypto, fiat, 'buy', bank)
        sell_data = count_fiat(crypto, fiat, 'sell', bank)

    '''if stock == "bybit":
        buy_data = count_fiat_bybit(crypto, fiat, 'buy', bank)
        sell_data = count_fiat_bybit(crypto, fiat, 'sell', bank)'''

    if stock == "huobi":
        buy_data = count_fiat_huobi(crypto, fiat, 'buy', bank)
        sell_data = count_fiat_huobi(crypto, fiat, 'sell', bank)

    '''if stock == "bestchange":
        buy_data = count_fiat_bestchange(crypto, fiat, 'buy', bank)
        sell_data = count_fiat_bestchange(crypto, fiat, 'sell', bank)'''

    if stock == "minfin":
        buy_data = count_fiat_minfin_new('buy')
        sell_data = count_fiat_minfin_new('sell')

    if stock == "whitebit":
        buy_data = count_fiat_whitebit(crypto, fiat, 'buy')
        sell_data = count_fiat_whitebit(crypto, fiat, 'sell')

    if stock == "binance_stock":
        buy_data = count_fiat_binance_stock(crypto, fiat, 'buy')
        sell_data = count_fiat_binance_stock(crypto, fiat, 'sell')

    if stock == "exmo":
        buy_data = count_fiat_exmo(crypto, fiat, 'buy')
        sell_data = count_fiat_exmo(crypto, fiat, 'sell')

    if stock == "bestchange":
        buy_data = get_bestchange_data_from_zip(crypto, fiat, 'sell')
        sell_data = get_bestchange_data_from_zip(crypto, fiat, 'buy')


    if len(buy_data) == 0 or len(sell_data) == 0:
        return False
    else:
        result.append(buy_data)
        result.append(sell_data)
        return result


def count_money_chain(chain):

    start_qurrency = Qurrency.objects.filter(
        stock=chain.start_stock,
        crypto=chain.start_crypto,
        fiat=chain.start_fiat,
        bank=chain.start_bank,
        type=chain.start_type
    ).last()

    finish_qurrency = Qurrency.objects.filter(
        stock=chain.finish_stock,
        crypto=chain.finish_crypto,
        fiat=chain.finish_fiat,
        bank=chain.finish_bank,
        type=chain.finish_type
    ).last()

    result = {}


    if chain.finish_value == 'a':
        result['spread'] = start_qurrency.avg - finish_qurrency.avg - start_qurrency.avg*(chain.comittion/100)
        result['start_price'] = start_qurrency.avg
        result['finish_price'] = finish_qurrency.avg
        result['comossion'] = start_qurrency.avg*(chain.comittion/100)


    if chain.finish_value == 'o':
        result['spread'] = start_qurrency.optimal - finish_qurrency.optimal - start_qurrency.optimal*(chain.comittion/100)
        result['start_price'] = start_qurrency.optimal
        result['finish_price'] = finish_qurrency.optimal
        result['comossion'] = start_qurrency.optimal * (chain.comittion / 100)


    if chain.finish_value == 't':
        result['spread'] = start_qurrency.top5 - finish_qurrency.top5 - start_qurrency.top5*(chain.comittion/100)
        result['start_price'] = start_qurrency.top5
        result['finish_price'] = finish_qurrency.top5
        result['comossion'] = start_qurrency.top5 * (chain.comittion / 100)


    result['spread'] = round(result['spread'], chain.rounding)
    result['start_price'] = round(result['start_price'], chain.rounding)
    result['finish_price'] = round(result['finish_price'], chain.rounding)
    result['comission'] = round(result['comossion'], chain.rounding)
    result['comittion'] = chain.comittion

    return result

def get_progons():
    from p2p.models import Progon, Card
    from p2p.gdocs_functions import get_google_spreadsheet_list
    data = get_google_spreadsheet_list()
    print(data)
    import datetime
    #print(data)

    result = {'count':0, 'success_list':[], 'error_list':[]}
    count = 0
    for row in data:
        from django.utils import timezone

        if Card.objects.filter(number=row['card']).count()>0:
            card = Card.objects.get(number=row['card'])

            new_datetime = datetime.datetime.strptime(f"{row['date']}.{datetime.datetime.now().year}", '%d.%m.%Y')
            tz = timezone.get_current_timezone()
            timzone_datetime = timezone.make_aware(new_datetime, tz, True)

            #date = datetime.datetime.strptime(f"{row['date']}.{datetime.datetime.now().year}", '%d.%m.%Y').date(OurTZ)
            date = timzone_datetime
            if Progon.objects.filter(card = card).filter(date = date).filter(summ = row['summ']).count()==0:
                p = Progon(
                    card = card,
                    summ = row['summ'],
                    date = date
                )
                p.save()
                result['success_list'].append({'card': card.number, 'summ': row['summ'], 'date': date})
                count += 1
                #print(p)
            else:
                pass
        else:
            result['error_list'].append(f"Card {row['card']} not found. Date: {row['date']} Summ: {row['summ']}")

    result['count'] = count
    print('load_progons works')
    return result

def count_balance():
    from p2p.models import Progon
    #progons = Progon.objects.filter(balance_counted=False).all()
    progons = Progon.objects.filter(balance_counted=False).all()
    #Sender.objects.update(ballance = 0)
    #Progon.objects.update(balance_counted = True)

    try:
        for progon in progons:
            fee = progon.summ * progon.card.drop.sender.comition
            transaction = P2p_transaction(
                sender = progon.card.drop.sender,
                drop = progon.card.drop,
                progon = progon,
                fee = fee,
            )
            transaction.save()

            Progon.objects.filter(id=progon.pk).update(balance_counted=True)
            Sender.objects.filter(id=progon.card.drop.sender.pk).update(ballance=progon.card.drop.sender.ballance+fee)
    except Exception as e:
        print(e)
        return False

    else:
        return True

def get_celery_beat_parsers_object():
    parsers = Parser.objects.filter(run=True).all()
    result = {}
    for parser in parsers:
        result[f'Parser_{parser.pk}_task'] = {
                        'task': 'p2p.tasks.get_currency_data_controller_beat',
                        'schedule': float(parser.delay),
                        'args': (parser.fiat, parser.crypto, parser.bank, parser.stock)
                    }
    return result

def save_celery_beat_parsers_config_to_json():
    data = get_celery_beat_parsers_object()
    try:
        with open('celery_beat_parsers.json', 'w') as outfile:
            json.dump(data, outfile)
    except Exception as e:
        print(e)
        return False


