from django.contrib import admin

# Register your models here.
from .models import *

class ParserChainAdmin(admin.ModelAdmin):
    list_display = ("stock", "crypto", "fiat", "bank", "delay", "run")

class MoneyChainChainAdmin(admin.ModelAdmin):
    list_display = ("name", "comittion")

class DropAdmin(admin.ModelAdmin):
    list_display = ("name",)
    verbose_name_plural = "Cards"

class BankAdmin(admin.ModelAdmin):
    list_display = ("name",)
    verbose_name_plural = "Cards"

class CardAdmin(admin.ModelAdmin):
    list_display = ("number","drop", "bank", "type","current_month_total","card_data", "cvv")
    verbose_name_plural = "Cards"

class ProgonAdmin(admin.ModelAdmin):
    #create castom filed
    list_display = ("card", "summ", 'date', 'balance_counted')

class SenderAdmin(admin.ModelAdmin):
    list_display = ("fio", "phone", 'telegram', 'comition','drop', 'ballance')
    readonly_fields = ['ballance',]

class P2p_transactionAdmin(admin.ModelAdmin):
    list_display = ("sender", "drop", "progon", 'fee', 'progon_data')


admin.site.register(MoneyChain,MoneyChainChainAdmin)
admin.site.register(Parser,ParserChainAdmin)
admin.site.register(Drop,DropAdmin)
admin.site.register(Card,CardAdmin)
admin.site.register(Bank,BankAdmin)
admin.site.register(Progon,ProgonAdmin)

admin.site.register(Sender,SenderAdmin)
admin.site.register(P2p_transaction,P2p_transactionAdmin)

