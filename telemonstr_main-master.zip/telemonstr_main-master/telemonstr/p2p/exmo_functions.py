import requests

def count_fiat_exmo(crypto, fiat, type):
    cookies = {
        'is_old_user': '1',
        'marker_hr': '%7B%22referrer%22%3A%22https%3A%2F%2Fwww.google.com%2F%22%2C%22target%22%3A%22%2F%22%7D',
        '_ga': 'GA1.2.255725424.1664904325',
        '_gid': 'GA1.2.455876382.1664904325',
        '_gat_gtag_UA_48018114_1': '1',
        '_hjFirstSeen': '1',
        '_hjIncludedInSessionSample': '0',
        '_hjSession_2846822': 'eyJpZCI6IjM0ZTg4OTBhLTRhZDMtNGIwNy1hNjdmLTRmOGY5MGM0MjY5MSIsImNyZWF0ZWQiOjE2NjQ5MDQzMjY2OTMsImluU2FtcGxlIjpmYWxzZX0=',
        '_hjAbsoluteSessionInProgress': '0',
        '_hjSessionUser_2846822': 'eyJpZCI6IjNjZWNiMTY3LWNhMzItNWY4ZS1hYWY1LWUwOWVjM2Y4ZTA5ZCIsImNyZWF0ZWQiOjE2NjQ5MDQzMjY0MDIsImV4aXN0aW5nIjp0cnVlfQ==',
        'lang': 'ru',
        'exmo_markets_lastSelectedPair': 'USDT_UAH',
    }

    headers = {
        'authority': 'exmo.me',
        'accept': 'application/json',
        'accept-language': 'ru,en-US;q=0.9,en;q=0.8,de;q=0.7,uk;q=0.6,ar;q=0.5',
        # Already added when you pass json=
        # 'content-type': 'application/json',
        # Requests sorts cookies= alphabetically
        # 'cookie': 'is_old_user=1; marker_hr=%7B%22referrer%22%3A%22https%3A%2F%2Fwww.google.com%2F%22%2C%22target%22%3A%22%2F%22%7D; _ga=GA1.2.255725424.1664904325; _gid=GA1.2.455876382.1664904325; _gat_gtag_UA_48018114_1=1; _hjFirstSeen=1; _hjIncludedInSessionSample=0; _hjSession_2846822=eyJpZCI6IjM0ZTg4OTBhLTRhZDMtNGIwNy1hNjdmLTRmOGY5MGM0MjY5MSIsImNyZWF0ZWQiOjE2NjQ5MDQzMjY2OTMsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=0; _hjSessionUser_2846822=eyJpZCI6IjNjZWNiMTY3LWNhMzItNWY4ZS1hYWY1LWUwOWVjM2Y4ZTA5ZCIsImNyZWF0ZWQiOjE2NjQ5MDQzMjY0MDIsImV4aXN0aW5nIjp0cnVlfQ==; lang=ru; exmo_markets_lastSelectedPair=USDT_UAH',
        'origin': 'https://exmo.me',
        'referer': 'https://exmo.me/trade/TRX_UAH',
        'sec-ch-ua': '"Google Chrome";v="105", "Not)A;Brand";v="8", "Chromium";v="105"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
    }

    json_data = {
        'pair': f"{crypto.upper()}_{fiat.upper()}",
    }

    response = requests.post('https://exmo.me/ctrl/book', cookies=cookies, headers=headers, json=json_data)
    #json unsersialize
    if type == 'buy':
        price = float(response.json()['data']['orders']['buy'][0][0])
    if type == 'sell':
        price = float(response.json()['data']['orders']['sell'][0][0])

    result = {
        'stock': 'exmo',
        'crypto': crypto,
        'fiat': fiat,
        'type': type,
        'bank': 'stock',
        'avg': {'avg_price': round(price, 2)},
        'optimal': {'avg_price': round(price, 2)},
        'top5': {'avg_price': round(price, 2)}
    }

    return result