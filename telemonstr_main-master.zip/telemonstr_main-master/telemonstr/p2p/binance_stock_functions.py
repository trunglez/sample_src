import requests


def count_fiat_binance_stock(crypto_label,fiat_label,type):

    if type == "buy":
        url = f"https://api.binance.com/api/v3/ticker/price?symbol={crypto_label.upper()}{fiat_label.upper()}"

    if type == "sell":
        url = f"https://api.binance.com/api/v3/ticker/price?symbol={crypto_label.upper()}{fiat_label.upper()}"
    binance_stock_answer = requests.get(url).json()


    result = {
        'stock': 'binance_stock',
        'crypto': crypto_label,
        'fiat': fiat_label,
        'type': type,
        'bank': 'stock',
        'avg': {'avg_price': float(binance_stock_answer['price'])},
        'optimal': {'avg_price':float(binance_stock_answer['price'])},
        'top5':  {'avg_price':float(binance_stock_answer['price'])}
    }



    return result