from django.shortcuts import render
from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from django.core import serializers
import requests
import time
from bs4 import BeautifulSoup
import json
from .functions import *
from .huobi_functions import *
from .bestchange_functions import *
import time
import telegram_send
from .models import *
from django.db.models import Q
from django.core import serializers
from .tasks import *
from django.views.generic import ListView
from p2p.serializers import SenderSerializer, SenderBallanceSerializer,SenderDetailSerializer
from rest_framework.viewsets import ModelViewSet

def binance_dashboard(request,fiat, crypto, bank):
    result = []
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'binance'))
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'huobi'))
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'minfin'))
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'whitebit'))

    data = {'title': bank,'fiat':fiat,'crypto':crypto, 'data': result}

    return render(request, 'p2p.html', context=data)
    #return HttpResponse(json.dumps(result), content_type="application/json")
def binance_dashboard_json(request,fiat, crypto, bank):
    result = []
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'binance'))
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'huobi'))
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'minfin'))
    result.append(exchange_get_dashboard_data(fiat, crypto, bank, 'whitebit'))
    return HttpResponse(json.dumps(result), content_type="application/json")

def binance_get_currency_list(request, fiat):
    result = get_buy_area(fiat)
    return HttpResponse(json.dumps(result), content_type="application/json")

def binance_bank_list(request, fiat):
    result = get_bank_list(fiat)
    return HttpResponse(json.dumps(result), content_type="application/json")

def test_page(request,crypto_label,fiat_label,type,payment_method):

    result = count_fiat(crypto_label,fiat_label,type,payment_method)

    return HttpResponse(json.dumps(result), content_type="application/json")

def bybit_dashboard(request,crypto, fiat, bank):
    result = count_fiat_bybit(crypto,fiat,"sell",bank)
    #result = get_bybit_banks()
    return HttpResponse(json.dumps(result), content_type="application/json")

def huobi_dashboard(request,crypto, fiat, bank):
    result = count_fiat_huobi(crypto, fiat, "buy", bank)
    return HttpResponse(json.dumps(result), content_type="application/json")

def bestchange_dashboard(request,crypto, fiat, bank):
    result = count_fiat_bestchange(crypto, fiat, 'sell', bank)
    return HttpResponse(json.dumps(result), content_type="application/json")

def p2p_telegram_message(request):
    print(vars(request.POST))
    message = f"{request.POST.get('bundle')} | {request.POST.get('spread')} | {request.POST.get('bank')}"
    telegram_send.send(messages=[message])
    return HttpResponse(json.dumps({'status':'ok'}), content_type="application/json")

def p2p_new_dashboard_json(request,fiat, crypto, bank):
    from django.utils import timezone
    stocks = ['binance', 'minfin','whitebit', 'binance_stock','exmo','bestchange']
    queryset = []
    for stock in stocks:
        sell_data = Qurrency.objects.filter(stock = stock).filter(fiat = fiat).filter(crypto=crypto).filter(Q(bank=bank) | Q(bank="stock")).filter(type='s').last()
        buy_data = Qurrency.objects.filter(stock = stock).filter(fiat = fiat).filter(crypto=crypto).filter(Q(bank=bank) | Q(bank="stock")).filter(type='b').last()
        buy_data.temp_var = sell_data.optimal
        buy_data.save()
        queryset.append(sell_data)
        queryset.append(buy_data)

    json = serializers.serialize("json", queryset)


    return HttpResponse(json, content_type="application/json")

def binance_newdashboard(request,fiat, crypto, bank):

    data = {'title': bank,'fiat':fiat,'crypto':crypto}

    return render(request, 'p2p_new_dashboard.html', context=data)

def p2p_chains(request):
    chains = MoneyChain.objects.all()
    result = []
    for chain in chains:
        chain_data = count_money_chain(chain)
        chain_data['name'] = chain.name
        chain_data['pk'] = chain.pk
        chain_data['favorites'] = chain.favorites
        result.append(chain_data)

    return HttpResponse(json.dumps(result), content_type="application/json")

def p2p_parsers(request):
    parsers = Parser.objects.all()
    return HttpResponse(serializers.serialize("json", parsers), content_type="application/json")

def p2p_parsers_page(request):
    data = {'title': 'Parsers'}

    return render(request, 'p2p_parsers.html', context=data)

def p2p_parsers_switchon(request,pk):
    result = {}

    try:
        parser = Parser.objects.filter(pk = pk).first()
        parser.run = True
        parser.save()

        result['status'] = 'ok'
        result['messsage'] = f'[switched on] Parser [{pk}] updated. {parser.hash}'

    except Exception as e:
        result['status'] = 'error'
        result['messsage'] = f'Parser [{pk}] is not updataed'

    return HttpResponse(json.dumps(result), content_type="application/json")




def p2p_parsers_switchoff(request,pk):
    result = {}
    from celery.result import AsyncResult

    try:
        parser = Parser.objects.filter(pk=pk).first()
        parser.run = False
        parser.save()
        result['status'] = 'ok'
        result['messsage'] = f'[switched off] Parser [{pk}] updated.'

    except Exception as e:
        result['status'] = 'error'
        result['messsage'] = f'Parser [{pk}] is not updataed'

    return HttpResponse(json.dumps(result), content_type="application/json")







def block_card(request):
    try:
        request_body = json.loads(request.body.decode('utf-8'))
        pk = request_body['pk']
        Card.objects.filter(pk = pk).update(blocked = True)
        return HttpResponse(json.dumps({'status': 'ok','pk':pk}), content_type="application/json")
    except Exception as e:
        return HttpResponse(json.dumps({'status':'error', 'message':str(e)}), content_type="application/json")

def unlock_card(request):
    try:
        request_body = json.loads(request.body.decode('utf-8'))
        pk = request_body['pk']
        Card.objects.filter(pk=pk).update(blocked=False)
        return HttpResponse(json.dumps({'status': 'ok', 'pk': pk}), content_type="application/json")
    except Exception as e:
        return HttpResponse(json.dumps({'status': 'error', 'message': str(e)}), content_type="application/json")

def p2p_senders(request):
    return render(request, 'senders.html', context={'title': 'Senders'})

def p2p_sender(request, pk):
    return render(request, 'sender.html', context={'title': 'Senders'})

class SenderViewSet(ModelViewSet):
    queryset = Sender.objects.all()
    serializer_class = SenderSerializer


def p2p_ballances(request):
    return render(request, 'ballances.html', context={'title': 'Ballances'})

class SenderBallaceViewSet(ModelViewSet):
    queryset = Sender.objects.all()
    serializer_class = SenderBallanceSerializer

class SendersViewSet(ModelViewSet):
    queryset = Sender.objects.all()
    serializer_class = SenderDetailSerializer
    lookup_field = 'sender_id'

    def get_queryset(self):
        return self.queryset

    def get_object(self):
        sender_id = self.kwargs['pk']
        return self.queryset.get(pk=sender_id)

    def list(self, request):
        senders = self.queryset
        serializers = self.get_serializer(senders, many=True)
        return HttpResponse(serializers.data, content_type="application/json")

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializers = self.get_serializer(instance, many=False)
        return HttpResponse(json.dumps(serializers.data), content_type="application/json")

