from django.db import models
from django.db.models import Sum
import datetime


# Create your models here.
class Qurrency(models.Model):

    CURRENCY_TYPES = (
        ('b', 'BUY'),
        ('s', 'SELL'),
    )

    stock = models.TextField(null = False, max_length=20)
    crypto = models.TextField(null = False, max_length=10)
    fiat = models.TextField(null = False, max_length=10)
    type = models.CharField(max_length=1, choices=CURRENCY_TYPES)
    bank = models.TextField(null = False, max_length=20)
    avg = models.FloatField(null=True, blank=True, default=0.0)
    optimal = models.FloatField(null=True, blank=True, default=0.0)

    top5 = models.FloatField(null=True, blank=True, default=0.0)
    date = models.DateTimeField(auto_now_add=True)

    temp_var = models.FloatField(null=True, blank=True, default=0.0)

class MoneyChain(models.Model):
    CURRENCY_VALUES = (
        ('a', 'avg'),
        ('o', 'optimal'),
        ('t', 'top5'),
    )
    CURRENCY_TYPES = (
        ('b', 'BUY'),
        ('s', 'SELL'),
    )

    name = models.CharField(null = False, max_length=200, default='-')
    start_stock = models.CharField(null = False, max_length=20)
    start_crypto = models.CharField(null = False, max_length=10)
    start_fiat = models.CharField(null = False, max_length=10)
    start_bank  = models.CharField(null = False, max_length=20)
    start_value = models.CharField(max_length=1, choices=CURRENCY_VALUES)
    start_type = models.CharField(max_length=1, choices=CURRENCY_TYPES)

    finish_stock = models.CharField(null=False, max_length=20)
    finish_crypto = models.CharField(null=False, max_length=10)
    finish_fiat = models.CharField(null=False, max_length=10)
    finish_bank = models.CharField(null=False, max_length=20)
    finish_value = models.CharField(max_length=1, choices=CURRENCY_VALUES)
    finish_type = models.CharField(max_length=1, choices=CURRENCY_TYPES)

    comittion = models.FloatField(null=True, blank=True, default=0.0)
    rounding = models.IntegerField(default=2)

    favorites = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.name}:{self.comittion}"

class Parser(models.Model):
    stock = models.CharField(null=False, max_length=20)
    crypto = models.CharField(null=False, max_length=10)
    fiat = models.CharField(null=False, max_length=10)
    bank = models.CharField(null=False, max_length=20)
    delay = models.IntegerField(default=60)
    hash = models.CharField(null=True, max_length=256,blank=True)
    run = models.BooleanField(default=False)



    def __str__(self):
        return f"{self.stock}:{self.crypto}:{self.fiat}:{self.bank}:{self.delay}:{self.run}"

class Sender(models.Model):
    fio = models.CharField(null=False, max_length=50)
    phone = models.CharField(null=False, max_length=20)
    telegram = models.CharField(null=False, max_length=20)
    comition = models.FloatField(null=True, blank=True, default=0.0)
    ballance = models.FloatField(null=True, blank=True, default=0.0)

    @property
    def drop(self):
        return self.drop_set.all()

    def __str__(self):
        return f"{self.fio}:{self.phone}:{self.telegram}:{self.comition}"




class Drop(models.Model):
    name = models.CharField(null=False, max_length=10)
    phone = models.CharField(null=True, max_length=20)
    sender = models.ForeignKey(Sender, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.name}"

class Bank(models.Model):
    name = models.CharField(null=False, max_length=10)
    month_max = models.IntegerField(null=True, blank=True, default=300000)

    def __str__(self):
        return f"{self.name}"


class Card(models.Model):
    CARD_TYPES = (
        ('b', 'internet'),
        ('s', 'plastic'),
    )
    number = models.BigIntegerField(null=False, unique=True)
    year = models.IntegerField(null=True, blank=True)
    month = models.IntegerField(null=True, blank=True)
    cvv = models.IntegerField(null=True, blank=True)
    pin = models.IntegerField(null=True, blank=True)
    drop = models.ForeignKey(Drop, on_delete=models.CASCADE, null=False)
    total = models.FloatField(null=False, default=0.0)
    current = models.FloatField(null=False, default=0.0)
    type = models.CharField(max_length=1, choices=CARD_TYPES)
    bank = models.ForeignKey(Bank, on_delete=models.CASCADE, null=False)
    comment = models.TextField(null=True, blank=True, default='')
    blocked = models.BooleanField(default=False)
    month_max = models.IntegerField(null=True, blank=True, default=30000)

    @property
    def current_month_total(self):
        month = datetime.datetime.now().month
        return Progon.objects.filter(card=self.pk, date__month=month).aggregate(Sum('summ'))['summ__sum']

    @property
    def card_data(self):
        return f"{self.month}/{self.year}"

    def __str__(self):
        return f"{self.number}:{self.drop.name}:{self.bank.name}"

class Transaction(models.Model):
    sender = models.ForeignKey(Sender, on_delete=models.CASCADE, null=False)
    drop = models.ForeignKey(Drop, on_delete=models.CASCADE, null=False)

class Progon(models.Model):
    card = models.ForeignKey(Card, on_delete=models.CASCADE, null=False)
    summ = models.FloatField(null=False, default=0.0)
    date = models.DateTimeField(auto_now_add=False, null=False, blank=False)
    transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE, null=True, blank=True)
    balance_counted = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.card}:{self.summ}:{self.date}"



class P2p_transaction(models.Model):
    sender = models.ForeignKey(Sender, on_delete=models.CASCADE, null=False)
    drop = models.ForeignKey(Drop, on_delete=models.CASCADE, null=True)
    progon = models.OneToOneField(Progon, on_delete=models.CASCADE, null=True)
    fee = models.FloatField(null=False, default=0.0)
    date = models.DateTimeField(auto_now_add=True, null=False, blank=False)

    @property
    def progon_data(self):
        return f"{self.progon.date}"



    def __str__(self):
        return f"{self.sender.name}:{self.summ}"




