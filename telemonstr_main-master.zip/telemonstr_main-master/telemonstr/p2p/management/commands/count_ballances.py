from django.core.management.base import BaseCommand, CommandError

class Command(BaseCommand):
    help = 'Count sender ballances'

    def add_arguments(self, parser):
        pass

    def handle(self, *args, **options):
        from p2p.functions import count_banance
        result = count_banance()
        if result:
            self.stdout.write(self.style.SUCCESS(f'Ballancs counted'))


        else:
            self.stdout.write(self.style.ERROR(f'Error'))