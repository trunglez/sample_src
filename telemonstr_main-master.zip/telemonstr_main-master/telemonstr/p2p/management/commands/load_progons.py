from django.core.management.base import BaseCommand, CommandError

class Command(BaseCommand):
    help = 'Loads Progons from file'

    def add_arguments(self, parser):
        pass

    def handle(self, *args, **options):
        from p2p.functions import get_progons
        result = get_progons()
        self.stdout.write(self.style.SUCCESS(f'Successfully loaded {result["count"]} Progons'))
        if len(result['success_list'])>0:
            for row in result['success_list']:
                self.stdout.write(self.style.WARNING(f'Successfully loaded Progon {row["summ"]} for card {row["card"]} on {row["date"]}'))

        if len(result['error_list']) > 0:
            for row in result['error_list']:
                self.stdout.write(self.style.ERROR(f'Error: {row}'))