from django.urls import path
from .views import *
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('senders', SenderViewSet, basename = 'senders')
router.register('ballances', SenderBallaceViewSet, basename = 'senders_ballance')


sender_api_list = SendersViewSet.as_view({'get': 'list'})
sender_api_detail = SendersViewSet.as_view({'get': 'retrieve'})




urlpatterns = router.urls

add_urls = [
    path('dashboard/<slug:fiat>/<slug:crypto>/<slug:bank>', binance_dashboard),
    path('newdashboard/<slug:fiat>/<slug:crypto>/<slug:bank>', binance_newdashboard),
    path('dashboard/api/<slug:fiat>/<slug:crypto>/<slug:bank>', binance_dashboard_json),
    path('newdashboard/api/<slug:fiat>/<slug:crypto>/<slug:bank>', p2p_new_dashboard_json),
    path('list/<slug:fiat>/',binance_get_currency_list),
    path('count/<slug:crypto_label>/<slug:fiat_label>/<slug:type>/<slug:payment_method>', test_page),
    path('banks/<slug:fiat>/', binance_bank_list),
    path('bybit/<slug:crypto>/<slug:fiat>/<slug:bank>', bybit_dashboard),
    path('huobi/<slug:crypto>/<slug:fiat>/<slug:bank>', huobi_dashboard),
    path('bestchange/<slug:crypto>/<slug:fiat>/<slug:bank>', bestchange_dashboard),
    path('telegram_send/', p2p_telegram_message),
    path('api/chains/', p2p_chains),
    path('api/parsers/', p2p_parsers),
    path('parsers/', p2p_parsers_page),
    path('parsers/swithon/<int:pk>', p2p_parsers_switchon),
    path('parsers/swithoff/<int:pk>', p2p_parsers_switchoff),
    path('dashboard/senders/', p2p_senders),
    path('blockcard/', block_card),
    path('unlockcard/', unlock_card),
    path('dashboard/ballances/', p2p_ballances),
    path(r'senders/', sender_api_list, name='api-senders'),
    path(r'api/sender/<int:pk>', sender_api_detail, name='api-sender-detail'),
    path('dashboard/sender_datail/<int:pk>', p2p_sender, name='sender-detail'),
]

for add_url in add_urls:
    urlpatterns.append(add_url)