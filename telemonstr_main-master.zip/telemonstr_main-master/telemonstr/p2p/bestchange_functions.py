import requests
import zipfile
import shutil
import os



#bestchange get zip file
def get_bestchange_zip():
    try:
        os.remove('p2p/static/bestchange.zip')
    except Exception as ex:
        print(ex)

    PROXIES = {
        'http': 'socks5://127.0.0.1:9050',
        'https': 'socks5://127.0.0.1:9050'
    }
    url = "http://api.bestchange.ru/info.zip"
    resp = requests.get(url, proxies=PROXIES)
    with open('p2p/static/bestchange.zip', 'wb') as f:
        f.write(resp.content)

    return resp.status_code

def unzip_file():
    try:
        shutil.rmtree('p2p/static/bestchange')
    except Exception as ex:
        print(ex)

    with zipfile.ZipFile('p2p/static/bestchange.zip', 'r') as zip_ref:
        zip_ref.extractall('p2p/static/bestchange')

def get_bestchange_data_from_zip(crypto, fiat, type, city=0, direction=0):
    fiat_id = 0
    crypto_id = 0

    if crypto == 'usdt':
        crypto_id = 10
    if fiat == 'uah':
        fiat_id = 60

    if fiat == 'usd':
        fiat_id = 89

    if type == 'buy':
        from_lable = crypto_id
        to_lable = fiat_id
    if type == 'sell':
        from_lable = fiat_id
        to_lable = crypto_id


    exchance_list = []
    curr_list = []

    with open('p2p/static/bestchange/bm_rates.dat', 'r', encoding='windows-1251') as f:
        file_data = f.readlines()
        for line in file_data:
            if city==0:
                if int(line.split(';')[0]) == from_lable and int(line.split(';')[1]) == to_lable:
                    exchance_list.append(line.split(';'))
            else:
                if int(line.split(';')[0]) == from_lable and int(line.split(';')[1]) == to_lable and int(line.replace('/n','').split(';')[10]) == int(city):
                    exchance_list.append(line.split(';'))


    if direction == 1:
        if type == 'buy':
            exchance_list.sort(key=lambda x: float(x[3]), reverse=False)
        if type == 'sell':
            exchance_list.sort(key=lambda x: float(x[4]), reverse=True)

        for val in exchance_list:
            if type == 'buy':
                curr_list.append(val[3])
            if type == 'sell':
                curr_list.append(val[4])
    else:
        if type == 'buy':
            exchance_list.sort(key=lambda x: float(x[4]), reverse=True)
        if type == 'sell':
            exchance_list.sort(key=lambda x: float(x[3]), reverse=False)
        for val in exchance_list:
            if type == 'buy':
                curr_list.append(val[4])
            if type == 'sell':
                curr_list.append(val[3])

    if type=='buy':
        type == 'sell'
    else:
        type == 'buy'

    result = {
        'stock': 'bestchange',
        'crypto': crypto,
        'fiat': fiat,
        'type': type,
        'bank': 'stock',
        'avg': {'avg_price': round(float(sum(map(float, curr_list[1:10])) / 9),3)},
        'optimal': {'avg_price': round(float(sum(map(float, curr_list[1:5])) / 4),3)},
        'top5': {'avg_price': round(float(sum(map(float, curr_list[1:5])) / 4),3)}
    }

    return result
