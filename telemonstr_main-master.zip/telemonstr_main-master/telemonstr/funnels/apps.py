from django.apps import AppConfig


class FunnelsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'funnels'
