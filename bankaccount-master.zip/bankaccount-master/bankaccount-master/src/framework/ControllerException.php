<?php
class ControllerException extends RuntimeException
{
}
