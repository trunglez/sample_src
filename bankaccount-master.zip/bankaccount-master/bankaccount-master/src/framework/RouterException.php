<?php
class RouterException extends RuntimeException
{
}
