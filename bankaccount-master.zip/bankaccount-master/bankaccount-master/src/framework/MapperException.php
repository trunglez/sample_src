<?php
class MapperException extends RuntimeException
{
}
