<?php
class BankAccountException extends RuntimeException
{
}
