<?php
class TestView extends View
{
    public function render()
    {
    }
}
