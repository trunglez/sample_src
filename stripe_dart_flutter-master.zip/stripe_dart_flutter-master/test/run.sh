#!/bin/bash

dart -c test/all_tests.dart $1