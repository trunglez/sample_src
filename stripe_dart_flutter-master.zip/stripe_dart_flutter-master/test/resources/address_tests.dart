library address_tests;

import 'dart:convert';

import 'package:test/test.dart';

import '../../lib/stripe_dart_flutter.dart';
import '../utils.dart' as utils;

var example = '''
    {
      "line1": "line1",
      "line2": "line2",
      "city": "city",
      "state": "state",
      "postal_code": "postal code",
      "country": "US"
    }''';

main(List<String> args) {
  utils.setApiKeyFromArgs(args);

  group('Address offline', () {
    test('fromMap() properly popullates all values', () {
      var map = jsonDecode(example);
      var address = Address.fromMap(map);
      expect(address.line1, map['line1']);
      expect(address.line2, map['line2']);
      expect(address.city, map['city']);
      expect(address.state, map['state']);
      expect(address.postalCode, map['postal_code']);
      expect(address.country, map['country']);
    });
  });
}
